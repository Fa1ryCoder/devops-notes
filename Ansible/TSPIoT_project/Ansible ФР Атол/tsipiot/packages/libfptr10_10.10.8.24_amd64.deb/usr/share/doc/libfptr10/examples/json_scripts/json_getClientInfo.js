function dateToString(date) {
    var pad = function (num) {
        var norm = Math.floor(Math.abs(num));
        return (norm < 10 ? '0' : '') + norm;
    };

    return date.getFullYear() + 
        '-' + pad(date.getMonth() + 1) +
        '-' + pad(date.getDate()) +
        ' ' + pad(date.getHours()) +
        ':' + pad(date.getMinutes()) +
        ':' + pad(date.getSeconds());
}

function execute(task) {
	var fnInfo = {};
	var kktInn = null;
	var kktRegistrationNumber = null;
	var kktSerialNumber = null;


	Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_FN_INFO);
	if (Fptr.fnQueryData() == 0) {
		fnInfo.serialNumber = Fptr.getParamString(Fptr.LIBFPTR_PARAM_SERIAL_NUMBER);
	}
	
	Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_VALIDITY);
	if (Fptr.fnQueryData() == 0) {
		fnInfo.validityDate = dateToString(Fptr.getParamDateTime(Fptr.LIBFPTR_PARAM_DATE_TIME));
	}
    
	Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_FREE_MEMORY);
	if (Fptr.fnQueryData() == 0) {
		fnInfo.fiscalDocumentCount = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_DOCUMENTS_COUNT);
		fnInfo.freeMemory          = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_FREE_MEMORY);
	}

	Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_LAST_DOCUMENT);
	if (Fptr.fnQueryData() == 0) {
		fnInfo.fiscalDocumentNumber = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_DOCUMENT_NUMBER);
	}

	Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_REG_INFO);
	if (Fptr.fnQueryData() == 0) {
		kktInn = Fptr.getParamString(1018);
		kktRegistrationNumber = Fptr.getParamString(1037);
	}

	Fptr.setParam(Fptr.LIBFPTR_PARAM_DATA_TYPE, Fptr.LIBFPTR_DT_SERIAL_NUMBER);
	if (Fptr.queryData() == 0) {
		kktSerialNumber = Fptr.getParamString(Fptr.LIBFPTR_PARAM_SERIAL_NUMBER);
	}

	return Fptr.ok({
		"fnInfo": fnInfo,
		"kktSerialNumber": kktSerialNumber,
		"kktInn": kktInn,
		"kktRegistrationNumber": kktRegistrationNumber
	});
}