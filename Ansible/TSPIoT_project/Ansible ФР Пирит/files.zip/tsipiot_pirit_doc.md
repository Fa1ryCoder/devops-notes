# ТС ПИоТ для ФР Пирит — установка через Ansible

## Структура проекта

```
~/ansible-cashregisters/
├── ansible.cfg
├── inventory/
│   └── hosts.yml                  ← список касс
├── group_vars/
│   └── cashregisters.yml          ← пароль root
├── host_vars/                      ← индивидуальные пароли (если отличаются)
├── templates/
│   └── esmmanager.ini.j2          ← шаблон конфига
└── playbooks/
    └── tsipiot_pirit.yml          ← плейбук
```

---

## Что нужно подготовить перед запуском

1. Положить `.deb` пакеты на кассовый сервер (`fa1ry`) в директорию `/opt/tsipiot/packages/`:
   - `esm_1.6.2.0_amd64.deb`
   - `esm-lm-controller_1.6.1.0_amd64.deb`
   - `esm-csi-dkkt_1.0.1_all.deb`

2. Добавить кассу в `inventory/hosts.yml`

3. Убедиться что `templates/esmmanager.ini.j2` лежит в правильном месте

---

## Что делает плейбук

### Блок 1 — Проверка версии
- Определяет тип кассы: РМК (`artix-pos`) или КСО (`artix-sst-sco`)
- Проверяет версию — допустимые: `4.6.304-10` или `5.304.10`
- Если версия не подходит — касса **пропускается** (`meta: end_host`), остальные продолжают выполняться

### Блок 2 — Обновление artix-comproxy
- Обновляет `artix-comproxy` через `aptitude install`
- Проверяет что версия `>= 1.15-62`
- Если версия ниже — касса **пропускается**

### Блок 3 — Установка .deb пакетов
- Устанавливает три пакета в строго заданном порядке:
  ```
  esm → esm-lm-controller → esm-csi-dkkt
  ```

### Блок 4 — Сертификаты
- Копирует сертификаты из `/etc/esp/` в `/usr/local/share/ca-certificates/`
- Запускает `update-ca-certificates`

### Блок 5 — Чтение crpt.ini
- Проверяет наличие файла `/linuxcash/cash/conf/ncash.ini.d/puppet/crpt.ini`
- Если файл есть — читает из секции `[LMCHZ]` значения `url`, `user`, `password`
- Парсит `url` — вытаскивает только IP/хост (из `http://10.16.7.21:5995` → `10.16.7.21`)
- Если файла нет — шаг пропускается, секция `[ESM.LMCHZ]` в конфиг не добавляется

### Блок 6 — Генерация ~esmmanager.ini
- Генерирует конфиг из шаблона `esmmanager.ini.j2`
- Если `crpt.ini` был найден — добавляет секцию `[ESM.LMCHZ]` с данными из него
- Кладёт готовый файл в `/linuxcash/cash/conf/ncash.ini.d/puppet/~esmmanager.ini`

### Блок 7 — Перезапуск comproxy
- Перезапускает сервис `comproxy` через `systemd`

---

## Запуск

```bash
cd ~/ansible-cashregisters
ansible-playbook playbooks/tsipiot_pirit.yml -i inventory/hosts.yml
```

Запуск на одной конкретной кассе (для теста):
```bash
ansible-playbook playbooks/tsipiot_pirit.yml -i inventory/hosts.yml --limit rmk-161
```

---

## Переменные (vars в плейбуке)

| Переменная | Значение по умолчанию | Описание |
|---|---|---|
| `allowed_pos_versions` | `["4.6.304-10", "5.304.10"]` | Допустимые версии artix-pos/artix-sst-sco |
| `deb_src_dir` | `/opt/tsipiot/packages` | Директория с .deb пакетами на fa1ry |
| `esm_conf_dest` | `/linuxcash/cash/conf/ncash.ini.d/puppet/~esmmanager.ini` | Путь назначения конфига |
| `crpt_ini_path` | `/linuxcash/cash/conf/ncash.ini.d/puppet/crpt.ini` | Путь к crpt.ini на кассе |
